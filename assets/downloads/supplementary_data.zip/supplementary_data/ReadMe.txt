Robot Skill Dataset Supplementary Sample

This archive contains compact trajectory excerpts sampled from one real-world
long-horizon episode and one simulation long-horizon episode. The files are
provided for inspecting the dataset format, prompt annotations, image fields,
state vectors, and action vectors.

Contents:
- dataset_manifest.json: high-level inventory for this sample archive.
- Summary.txt: concise description of the supplementary objects.
- data_format.md: field-level format notes.
- inspect_sample.py: command-line utility for inspecting schemas, prompts, and sample rows.
- samples/real_world/desk_org: one real-world long-horizon sample.
- samples/sim_bench/turn_on_stove_put_moka_pot: one simulation long-horizon sample.
- previews: small visual contact sheets and videos generated from the sampled trajectories.

Requirements:
- Python 3.10 or newer
- pyarrow for reading parquet files
- a standard MP4 player for the preview videos

Prompt annotations in this sample were generated automatically with GPT-4o.
Minor linguistic imperfections may therefore remain in the annotations.

License and attribution:
- The simulation sample is derived from the LIBERO dataset, which is released
  under the Creative Commons Attribution 4.0 International license (CC BY 4.0).
  Original project: https://github.com/Lifelong-Robot-Learning/LIBERO
- Public release terms for the complete real-world dataset will be specified after internal
  review.


