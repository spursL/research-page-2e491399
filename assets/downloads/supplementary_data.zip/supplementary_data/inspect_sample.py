#!/usr/bin/env python3
"""Inspect the supplementary trajectory samples without printing image bytes."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq


ARCHIVE_ROOT = Path(__file__).resolve().parent


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Inspect sample schemas, prompts, and representative rows."
    )
    parser.add_argument(
        "--sample",
        choices=("all", "real_world", "sim_bench"),
        default="all",
        help="Select a sample domain (default: all).",
    )
    parser.add_argument(
        "--rows",
        type=int,
        default=2,
        help="Number of representative rows to print per sample (default: 2).",
    )
    parser.add_argument(
        "--extract-images",
        type=Path,
        help="Optionally export the first embedded images to this directory.",
    )
    parser.add_argument(
        "--image-count",
        type=int,
        default=3,
        help="Images to export per camera field when --extract-images is used (default: 3).",
    )
    return parser.parse_args()


def is_image_field(field: pa.Field) -> bool:
    if not pa.types.is_struct(field.type):
        return False
    return {child.name for child in field.type} >= {"bytes", "path"}


def compact_value(value: Any) -> Any:
    if isinstance(value, float):
        return round(value, 6)
    if isinstance(value, list):
        return [compact_value(item) for item in value]
    return value


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value)


def export_images(
    table: pa.Table,
    image_fields: list[str],
    sample_name: str,
    output_dir: Path,
    image_count: int,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for field_name in image_fields:
        for index, image in enumerate(table[field_name].to_pylist()[:image_count]):
            if not image or not image.get("bytes"):
                continue
            original_path = image.get("path") or "frame.png"
            suffix = Path(original_path).suffix or ".png"
            filename = safe_name(f"{sample_name}_{field_name}_{index:03d}{suffix}")
            destination = output_dir / filename
            destination.write_bytes(image["bytes"])
            print(f"  exported: {destination}")


def inspect_sample(
    record: dict[str, Any],
    rows: int,
    extract_dir: Path | None,
    image_count: int,
) -> None:
    sample_name = f"{record['domain']}/{record['skill']}"
    data_path = ARCHIVE_ROOT / record["data_file"]
    table = pq.read_table(data_path)
    if table.num_rows != record["frames"]:
        raise ValueError(
            f"Manifest mismatch for {sample_name}: "
            f"expected {record['frames']} rows, found {table.num_rows}."
        )

    image_fields = [
        field.name for field in table.schema if is_image_field(field)
    ]
    print(f"\n[{sample_name}]")
    print(f"file: {data_path.relative_to(ARCHIVE_ROOT)}")
    print(f"rows: {table.num_rows}")
    print("schema:")
    for field in table.schema:
        print(f"  - {field.name}: {field.type}")

    for prompt_field in ("overall_task", "subtask"):
        if prompt_field not in table.column_names:
            continue
        prompts = sorted(set(table[prompt_field].to_pylist()))
        print(f"{prompt_field} values:")
        for prompt in prompts:
            print(f"  - {prompt}")

    printable_fields = [
        name for name in table.column_names if name not in image_fields
    ]
    row_count = min(max(rows, 0), table.num_rows)
    if row_count:
        print(f"first {row_count} row(s), excluding image bytes:")
        for index in range(row_count):
            row = {
                name: compact_value(table[name][index].as_py())
                for name in printable_fields
            }
            print(json.dumps(row, ensure_ascii=False))

    for field_name in image_fields:
        values = table[field_name].to_pylist()
        embedded = sum(bool(item and item.get("bytes")) for item in values)
        paths = [item.get("path") for item in values if item and item.get("path")]
        print(
            f"image field {field_name}: {embedded} embedded images; "
            f"first path: {paths[0] if paths else 'n/a'}"
        )

    if extract_dir is not None:
        export_images(table, image_fields, sample_name, extract_dir, image_count)


def main() -> None:
    args = parse_args()
    if args.rows < 0 or args.image_count < 0:
        raise SystemExit("--rows and --image-count must be non-negative.")

    manifest_path = ARCHIVE_ROOT / "dataset_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    print(manifest["name"])
    print(f"sample_only: {manifest.get('sample_only', False)}")

    selected = [
        record
        for record in manifest["samples"]
        if args.sample == "all" or record["domain"] == args.sample
    ]
    for record in selected:
        inspect_sample(record, args.rows, args.extract_images, args.image_count)


if __name__ == "__main__":
    main()
