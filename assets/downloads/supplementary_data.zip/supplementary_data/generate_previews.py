#!/usr/bin/env python3
"""Generate side-by-side MP4 previews from the supplementary Parquet samples."""

from __future__ import annotations

import argparse
import io
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from PIL import Image, ImageDraw, ImageFont


ARCHIVE_ROOT = Path(__file__).resolve().parent
PANEL_SIZE = (320, 240)
VIDEO_SIZE = (640, 292)
DEFAULT_FPS = 6.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate annotated MP4 previews from embedded Parquet images."
    )
    parser.add_argument(
        "--sample",
        choices=("all", "real_world", "sim_bench"),
        default="all",
        help="Select a sample domain (default: all).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("generated_previews"),
        help=(
            "Output directory, relative to the archive root unless absolute "
            "(default: generated_previews)."
        ),
    )
    parser.add_argument(
        "--fps",
        type=float,
        default=DEFAULT_FPS,
        help=f"Output frame rate (default: {DEFAULT_FPS:g}).",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacement of existing output videos.",
    )
    return parser.parse_args()


def is_image_field(field: pa.Field) -> bool:
    if not pa.types.is_struct(field.type):
        return False
    return {child.name for child in field.type} >= {"bytes", "path"}


def decode_image(image_record: dict[str, Any], field_name: str, row: int) -> Image.Image:
    image_bytes = image_record.get("bytes") if image_record else None
    if not image_bytes:
        raise ValueError(f"Missing image bytes in {field_name} at row {row}.")
    with Image.open(io.BytesIO(image_bytes)) as image:
        return image.convert("RGB").resize(PANEL_SIZE, Image.Resampling.BICUBIC)


def render_frame(
    table: pa.Table,
    image_fields: list[str],
    row: int,
    font: ImageFont.ImageFont,
) -> np.ndarray:
    canvas = Image.new("RGB", VIDEO_SIZE, "white")
    for panel_index, field_name in enumerate(image_fields):
        image_record = table[field_name][row].as_py()
        panel = decode_image(image_record, field_name, row)
        canvas.paste(panel, (panel_index * PANEL_SIZE[0], 0))

    frame_index = table["frame_index"][row].as_py()
    subtask = table["subtask"][row].as_py()
    draw = ImageDraw.Draw(canvas)
    draw.text((6, 246), image_fields[0], fill="black", font=font)
    draw.text((326, 246), image_fields[1], fill="black", font=font)
    draw.text((6, 268), f"frame {frame_index}: {subtask}", fill="black", font=font)
    return cv2.cvtColor(np.asarray(canvas), cv2.COLOR_RGB2BGR)


def generate_video(
    record: dict[str, Any],
    output_dir: Path,
    fps: float,
    overwrite: bool,
) -> Path:
    sample_name = f"{record['domain']}/{record['skill']}"
    data_path = ARCHIVE_ROOT / record["data_file"]
    table = pq.read_table(data_path)
    if table.num_rows != record["frames"]:
        raise ValueError(
            f"Manifest mismatch for {sample_name}: "
            f"expected {record['frames']} rows, found {table.num_rows}."
        )
    if "frame_index" not in table.column_names or "subtask" not in table.column_names:
        raise ValueError(f"{sample_name} requires frame_index and subtask columns.")

    image_fields = [field.name for field in table.schema if is_image_field(field)]
    if len(image_fields) != 2:
        raise ValueError(
            f"{sample_name} requires exactly two image fields; found {image_fields}."
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    destination = output_dir / f"{record['domain']}_{record['skill']}.mp4"
    if destination.exists() and not overwrite:
        raise FileExistsError(
            f"Output already exists: {destination}. Use --overwrite to replace it."
        )

    temporary = destination.with_name(f".{destination.stem}.temporary.mp4")
    writer = cv2.VideoWriter(
        str(temporary),
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        VIDEO_SIZE,
    )
    if not writer.isOpened():
        raise RuntimeError(f"Could not open MP4 writer for {temporary}.")

    font = ImageFont.load_default()
    try:
        for row in range(table.num_rows):
            writer.write(render_frame(table, image_fields, row, font))
    finally:
        writer.release()

    temporary.replace(destination)
    print(
        f"generated: {destination} "
        f"({table.num_rows} frames at {fps:g} FPS)"
    )
    return destination


def main() -> None:
    args = parse_args()
    if args.fps <= 0:
        raise SystemExit("--fps must be positive.")

    output_dir = args.output_dir
    if not output_dir.is_absolute():
        output_dir = ARCHIVE_ROOT / output_dir

    manifest = json.loads(
        (ARCHIVE_ROOT / "dataset_manifest.json").read_text(encoding="utf-8")
    )
    selected = [
        record
        for record in manifest["samples"]
        if args.sample == "all" or record["domain"] == args.sample
    ]
    for record in selected:
        generate_video(record, output_dir, args.fps, args.overwrite)


if __name__ == "__main__":
    main()
