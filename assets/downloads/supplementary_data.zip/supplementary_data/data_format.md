# Data Format

The archive contains two trajectory excerpts in parquet format.

## Inspecting the Samples

Install the required reader and run the inspection utility from the extracted
archive directory:

```bash
python -m pip install pyarrow
python inspect_sample.py
```

The default command prints the schema, prompt values, representative rows, and
embedded-image counts for both samples without printing binary image data. To
inspect only one domain or print more rows, use:

```bash
python inspect_sample.py --sample real_world --rows 4
python inspect_sample.py --sample sim_bench --rows 4
```

Embedded observations can optionally be extracted as image files:

```bash
python inspect_sample.py --extract-images extracted_frames --image-count 3
```

Run `python inspect_sample.py --help` for all options. Prompt annotations in
this archive were generated automatically with GPT-4o and may contain minor
linguistic imperfections.

## Real-World Sample

Path: `samples/real_world/desk_org`

Main data file:
`data/chunk-000/episode_000000.parquet`

Fields:
- `state`: robot state vector.
- `actions`: robot action vector.
- `exterior_image`: RGB observation stored as `{bytes, path}`.
- `wrist_image_left`: wrist-camera RGB observation stored as `{bytes, path}`.
- `subtask`: atomic skill prompt for each frame.
- `task_index`: high-level prompt index.
- `timestamp`, `frame_index`, `episode_index`, `index`: trajectory indices.

Prompt metadata:
- `meta/tasks.jsonl` contains the high-level task prompt.
- `meta/skill_composition.jsonl` records the sampled subtask segments.

## Simulation Sample

Path: `samples/sim_bench/turn_on_stove_put_moka_pot`

Main data file:
`data/chunk-000/file-000.parquet`

Fields:
- `state`: simulator state vector.
- `actions`: action vector.
- `images.agentview_rgb`: agent-view RGB observation stored as `{bytes, path}`.
- `images.wrist_rgb`: wrist-view RGB observation stored as `{bytes, path}`.
- `overall_task`: long-horizon prompt.
- `subtask`: frame-level skill prompt.
- `timestamp`, `frame_index`, `episode_index`, `index`, `task_index`: trajectory indices.

The sample trajectories are downsampled excerpts for review-time inspection.
They are not intended to reproduce the full experimental scale.
